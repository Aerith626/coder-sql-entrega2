USE db_blog;

-- AUTORES
INSERT INTO autores (id_autor, nombre, apellido, email, `contraseña`, fecha_creacion, fecha_actualizacion) VALUES
(1,'Ana','López','ana.lopez@example.com','pass1','2025-01-05 10:00:00','2025-01-05 10:00:00'),
(2,'Carlos','Fernández','carlos.fernandez@example.com','pass2','2025-01-06 11:00:00','2025-01-06 11:00:00'),
(3,'María','Rodríguez','maria.rodriguez@example.com','pass3','2025-01-07 12:00:00','2025-01-07 12:00:00'),
(4,'Pedro','Pérez','pedro.perez@example.com','pass4','2025-01-08 13:00:00','2025-01-08 13:00:00'),
(5,'Laura','Díaz','laura.diaz@example.com','pass5','2025-01-09 14:00:00','2025-01-09 14:00:00'),
(6,'Jorge','Martínez','jorge.martinez@example.com','pass6','2025-01-10 15:00:00','2025-01-10 15:00:00'),
(7,'Sofía','Gómez','sofia.gomez@example.com','pass7','2025-01-11 16:00:00','2025-01-11 16:00:00'),
(8,'Alejandro','Ruiz','alejandro.ruiz@example.com','pass8','2025-01-12 17:00:00','2025-01-12 17:00:00'),
(9,'Valentina','Ortega','valentina.ortega@example.com','pass9','2025-01-13 18:00:00','2025-01-13 18:00:00'),
(10,'Bruno','Silva','bruno.silva@example.com','pass10','2025-01-14 19:00:00','2025-01-14 19:00:00');

-- USUARIOS
INSERT INTO usuarios (id_usuario, nombre_usuario, email, `contraseña`, fecha_creacion) VALUES
(1,'user_ana','ana.user@example.com','upass1','2025-02-01 09:00:00'),
(2,'user_carlos','carlos.user@example.com','upass2','2025-02-02 09:00:00'),
(3,'user_maria','maria.user@example.com','upass3','2025-02-03 09:00:00'),
(4,'user_pedro','pedro.user@example.com','upass4','2025-02-04 09:00:00'),
(5,'user_laura','laura.user@example.com','upass5','2025-02-05 09:00:00'),
(6,'user_jorge','jorge.user@example.com','upass6','2025-02-06 09:00:00'),
(7,'user_sofia','sofia.user@example.com','upass7','2025-02-07 09:00:00'),
(8,'user_alejandro','alejandro.user@example.com','upass8','2025-02-08 09:00:00'),
(9,'user_valentina','valentina.user@example.com','upass9','2025-02-09 09:00:00'),
(10,'user_bruno','bruno.user@example.com','upass10','2025-02-10 09:00:00');

-- CATEGORIAS
INSERT INTO categorias (id_categoria, nombre, slug) VALUES
(1,'Tecnología','tecnologia'),
(2,'Desarrollo Web','desarrollo-web'),
(3,'Base de Datos','base-de-datos'),
(4,'DevOps','devops'),
(5,'Diseño','diseno'),
(6,'Marketing','marketing'),
(7,'Seguridad','seguridad'),
(8,'Ciencia','ciencia'),
(9,'Opiniones','opiniones'),
(10,'Tutoriales','tutoriales');

-- PUBLICACIONES
INSERT INTO publicaciones (id_publicacion, id_autor, id_categoria, titulo, slug, contenido, estado, fecha_creacion, fecha_actualizacion, fecha_publicacion) VALUES
(1,2,4,'Docker para principiantes','docker-para-principiantes','Breve introducción a Docker y contenedores.','publicada','2025-03-01 10:00:00','2025-03-01 10:00:00','2025-03-01 10:00:00'),
(2,1,2,'Cómo crear un layout responsive','como-crear-un-layout-responsive','Guía práctica con ejemplos en HTML y CSS.','publicada','2025-03-05 09:00:00','2025-03-05 09:00:00','2025-03-05 09:00:00'),
(3,3,3,'Índice de rendimiento en MySQL','indice-de-rendimiento-mysql','Explicación sobre EXPLAIN, índices y optimización.','publicada','2025-03-10 11:00:00','2025-03-10 11:00:00','2025-03-10 11:00:00'),
(4,4,1,'Tendencias en IA 2025','tendencias-ia-2025','Reflexiones sobre modelos y ética.','borrador','2025-04-01 12:00:00','2025-04-01 12:00:00',NULL),
(5,5,5,'Principios de UX','principios-de-ux','Buenas prácticas para diseño centrado en el usuario.','publicada','2025-04-10 08:30:00','2025-04-10 08:30:00','2025-04-10 08:30:00'),
(6,6,6,'Estrategias de marketing digital','estrategias-marketing-digital','Cómo planificar campañas y medir KPIs.','archivada','2025-04-15 10:00:00','2025-04-15 10:00:00','2025-04-15 10:00:00'),
(7,7,10,'Tutorial: crear un blog con SQL','tutorial-crear-blog-sql','Paso a paso para montar un blog y su base de datos.','publicada','2025-05-01 09:20:00','2025-05-01 09:20:00','2025-05-01 09:20:00'),
(8,8,2,'CSS Grid vs Flexbox','css-grid-vs-flexbox','Comparativa práctica y cuándo usar cada uno.','publicada','2025-05-03 14:00:00','2025-05-03 14:00:00','2025-05-03 14:00:00'),
(9,9,7,'Seguridad: conceptos básicos','seguridad-conceptos-basicos','Autenticación, autorización y buenas prácticas.','publicada','2025-05-05 16:00:00','2025-05-05 16:00:00','2025-05-05 16:00:00'),
(10,10,8,'Últimos avances científicos','ultimos-avances-cientificos','Listado de descubrimientos y enlaces a papers.','borrador','2025-05-10 10:00:00','2025-05-10 10:00:00',NULL);

-- COMENTARIOS
INSERT INTO comentarios (id_comentario, id_publicacion, id_usuario, contenido, fecha_creacion, aprobado) VALUES
(1,1,3,'Excelente artículo, me ayudó mucho.','2025-03-02 12:00:00',1),
(2,1,4,'Comentario spam','2025-03-02 12:30:00',0),
(3,2,1,'¿Tienes código de ejemplo?','2025-03-06 10:00:00',1),
(4,3,5,'Buen enfoque, gracias.','2025-03-11 15:00:00',1),
(5,3,2,'Otro comentario spam','2025-03-12 09:00:00',0),
(6,4,6,'Interesante, espero la versión final.','2025-04-02 08:00:00',1),
(7,7,8,'Muy útil el tutorial :) gracias!!!','2025-05-02 11:00:00',1),
(8,8,9,'No estoy de acuerdo con la comparación.','2025-05-04 17:00:00',1),
(9,9,10,'¿Recomiendas herramientas gratuitas?','2025-05-06 19:00:00',1),
(10,5,7,'gracias','2025-04-11 09:30:00',0);

