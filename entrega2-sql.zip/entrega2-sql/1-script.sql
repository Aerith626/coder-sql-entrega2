CREATE SCHEMA db_blog;
USE db_blog;

CREATE TABLE autores (
    id_autor INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE usuarios (
    id_usuario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) UNIQUE,
    contrasena VARCHAR(255),
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categorias (
    id_categoria INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    slug VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE publicaciones (
    id_publicacion INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_autor INT NOT NULL,
    id_categoria INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    slug VARCHAR(200) NOT NULL UNIQUE,
    contenido TEXT NOT NULL,
    estado ENUM('borrador','publicada','archivada') DEFAULT 'borrador',
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    fecha_publicacion DATETIME,
    CONSTRAINT fk_publicaciones_autor FOREIGN KEY (id_autor) REFERENCES autores(id_autor),
    CONSTRAINT fk_publicaciones_categoria FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
);

CREATE TABLE comentarios (
    id_comentario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_publicacion INT NOT NULL,
    id_usuario INT NOT NULL,
    contenido TEXT NOT NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    aprobado BOOLEAN DEFAULT FALSE,
    CONSTRAINT fk_comentarios_publicacion FOREIGN KEY (id_publicacion) REFERENCES publicaciones(id_publicacion),
    CONSTRAINT fk_comentarios_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

-- Publicaciones con autor y categoría
CREATE OR REPLACE VIEW vw_publicaciones_publicadas AS
SELECT p.id_publicacion,
       p.titulo,
       LEFT(p.contenido,200) AS snippet,
       CONCAT(a.nombre, ' ', a.apellido) AS autor,
       c.nombre AS categoria,
       p.fecha_publicacion
FROM publicaciones p
JOIN autores a ON p.id_autor = a.id_autor
JOIN categorias c ON p.id_categoria = c.id_categoria
WHERE p.estado = 'publicada';

-- Estadisticas por autor
CREATE OR REPLACE VIEW vw_autores_estadisticas AS
SELECT a.id_autor,
       a.nombre,
       a.apellido,
       COUNT(DISTINCT p.id_publicacion) AS total_publicaciones,
       COUNT(cm.id_comentario) AS total_comentarios,
       MAX(p.fecha_publicacion) AS ultima_publicacion
FROM autores a
LEFT JOIN publicaciones p ON a.id_autor = p.id_autor
LEFT JOIN comentarios cm ON p.id_publicacion = cm.id_publicacion
GROUP BY a.id_autor;

-- Publicaciones con comentarios recientes (ultimos 30 dias) y cantidad
CREATE OR REPLACE VIEW vw_publicaciones_comentarios_recientes AS
SELECT p.id_publicacion,
       p.titulo,
       COUNT(cm.id_comentario) AS comentarios_ult_30dias
FROM publicaciones p
LEFT JOIN comentarios cm ON p.id_publicacion = cm.id_publicacion
  AND cm.fecha_creacion >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY p.id_publicacion
HAVING comentarios_ult_30dias > 0;

DELIMITER $$

-- Convertir texto en slug (para links)
CREATE FUNCTION fn_slugify(in_text VARCHAR(255)) RETURNS VARCHAR(255) DETERMINISTIC
BEGIN
  DECLARE s VARCHAR(255);
  SET s = LOWER(TRIM(in_text));
  SET s = REPLACE(s, ' ', '-');
  SET s = REPLACE(s, '''', '');
  SET s = REPLACE(s, '"', '');
  SET s = REPLACE(s, ',', '');
  SET s = REPLACE(s, '.', '');
  SET s = REPLACE(s, ':', '');
  SET s = REPLACE(s, ';', '');
  SET s = REPLACE(s, '/', '-');
  SET s = REPLACE(s, '_', '-');
  WHILE INSTR(s, '--') > 0 DO
    SET s = REPLACE(s, '--', '-');
  END WHILE;
  RETURN TRIM(BOTH '-' FROM s);
END$$

-- Contar los comentarios de una publicacion
CREATE FUNCTION fn_count_comments(p_id INT) RETURNS INT DETERMINISTIC
BEGIN
  DECLARE cnt INT DEFAULT 0;
  SELECT COUNT(*) INTO cnt FROM comentarios WHERE id_publicacion = p_id;
  RETURN cnt;
END$$

DELIMITER ;

DELIMITER $$

-- Obtener publicaciones por autor
CREATE PROCEDURE sp_get_publicaciones_por_autor(IN in_autor_id INT)
BEGIN
  SELECT p.id_publicacion, p.titulo, p.estado, p.fecha_publicacion,
         LEFT(p.contenido,200) AS snippet,
         c.nombre AS categoria
  FROM publicaciones p
  JOIN categorias c ON p.id_categoria = c.id_categoria
  WHERE p.id_autor = in_autor_id
  ORDER BY p.fecha_creacion DESC;
END$$

-- Buscar publicaciones por palabra clave en titulo o contenido
CREATE PROCEDURE sp_search_publicaciones_por_keyword(IN in_keyword VARCHAR(200))
BEGIN
  SELECT p.id_publicacion, p.titulo, LEFT(p.contenido,200) AS snippet,
         CONCAT(a.nombre,' ',a.apellido) AS autor, c.nombre AS categoria, p.estado
  FROM publicaciones p
  JOIN autores a ON p.id_autor = a.id_autor
  JOIN categorias c ON p.id_categoria = c.id_categoria
  WHERE p.titulo LIKE CONCAT('%', in_keyword, '%')
     OR p.contenido LIKE CONCAT('%', in_keyword, '%')
  ORDER BY p.fecha_publicacion DESC;
END$$

DELIMITER ;

-- Generar slug automáticamente en publicaciones
DELIMITER //
CREATE TRIGGER trg_generate_slug
BEFORE INSERT ON publicaciones
FOR EACH ROW
BEGIN
  SET NEW.slug = LOWER(REPLACE(NEW.titulo, ' ', '-'));
END;
//
DELIMITER ;

-- Trigger al insertar un comentario
DELIMITER //
CREATE TRIGGER trg_comentario_before_insert
BEFORE INSERT ON comentarios
FOR EACH ROW
BEGIN
  -- Auto aprobar el comentario antes de insertarlo
  SET NEW.aprobado = 1;

  -- Actualizar la fecha de la publicacion
  UPDATE publicaciones
  SET fecha_actualizacion = NOW()
  WHERE id_publicacion = NEW.id_publicacion;
END;
//
DELIMITER ;