DELIMITER $$

-- Convertir texto en slug (para links)
CREATE FUNCTION fn_slugify(in_text VARCHAR(255)) RETURNS VARCHAR(255) DETERMINISTIC
BEGIN
  DECLARE s VARCHAR(255);
  SET s = LOWER(TRIM(in_text));
  SET s = REPLACE(s, ' ', '-');
  SET s = REPLACE(s, '''', '');
  SET s = REPLACE(s, '"', '');
  SET s = REPLACE(s, ',', '');
  SET s = REPLACE(s, '.', '');
  SET s = REPLACE(s, ':', '');
  SET s = REPLACE(s, ';', '');
  SET s = REPLACE(s, '/', '-');
  SET s = REPLACE(s, '_', '-');
  WHILE INSTR(s, '--') > 0 DO
    SET s = REPLACE(s, '--', '-');
  END WHILE;
  RETURN TRIM(BOTH '-' FROM s);
END$$

-- Contar los comentarios de una publicacion
CREATE FUNCTION fn_count_comments(p_id INT) RETURNS INT DETERMINISTIC
BEGIN
  DECLARE cnt INT DEFAULT 0;
  SELECT COUNT(*) INTO cnt FROM comentarios WHERE id_publicacion = p_id;
  RETURN cnt;
END$$

DELIMITER ;
