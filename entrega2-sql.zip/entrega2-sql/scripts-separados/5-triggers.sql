-- Generar slug automáticamente en publicaciones
DELIMITER //
CREATE TRIGGER trg_generate_slug
BEFORE INSERT ON publicaciones
FOR EACH ROW
BEGIN
  SET NEW.slug = LOWER(REPLACE(NEW.titulo, ' ', '-'));
END;
//
DELIMITER ;

-- Trigger al insertar un comentario
DELIMITER //
CREATE TRIGGER trg_comentario_before_insert
BEFORE INSERT ON comentarios
FOR EACH ROW
BEGIN
  -- Auto aprobar el comentario antes de insertarlo
  SET NEW.aprobado = 1;

  -- Actualizar la fecha de la publicacion
  UPDATE publicaciones
  SET fecha_actualizacion = NOW()
  WHERE id_publicacion = NEW.id_publicacion;
END;
//
DELIMITER ;