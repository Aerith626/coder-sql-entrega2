DELIMITER $$

-- Obtener publicaciones por autor
CREATE PROCEDURE sp_get_publicaciones_por_autor(IN in_autor_id INT)
BEGIN
  SELECT p.id_publicacion, p.titulo, p.estado, p.fecha_publicacion,
         LEFT(p.contenido,200) AS snippet,
         c.nombre AS categoria
  FROM publicaciones p
  JOIN categorias c ON p.id_categoria = c.id_categoria
  WHERE p.id_autor = in_autor_id
  ORDER BY p.fecha_creacion DESC;
END$$

-- Buscar publicaciones por palabra clave en titulo o contenido
CREATE PROCEDURE sp_search_publicaciones_por_keyword(IN in_keyword VARCHAR(200))
BEGIN
  SELECT p.id_publicacion, p.titulo, LEFT(p.contenido,200) AS snippet,
         CONCAT(a.nombre,' ',a.apellido) AS autor, c.nombre AS categoria, p.estado
  FROM publicaciones p
  JOIN autores a ON p.id_autor = a.id_autor
  JOIN categorias c ON p.id_categoria = c.id_categoria
  WHERE p.titulo LIKE CONCAT('%', in_keyword, '%')
     OR p.contenido LIKE CONCAT('%', in_keyword, '%')
  ORDER BY p.fecha_publicacion DESC;
END$$

DELIMITER ;
