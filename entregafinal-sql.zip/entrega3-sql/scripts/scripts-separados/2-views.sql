-- Publicaciones con autor y categoría
CREATE OR REPLACE VIEW vw_publicaciones_publicadas AS
SELECT p.id_publicacion,
       p.titulo,
       LEFT(p.contenido,200) AS snippet,
       CONCAT(a.nombre, ' ', a.apellido) AS autor,
       c.nombre AS categoria,
       p.fecha_publicacion
FROM publicaciones p
JOIN autores a ON p.id_autor = a.id_autor
JOIN categorias c ON p.id_categoria = c.id_categoria
WHERE p.estado = 'publicada';

-- Estadisticas por autor
CREATE OR REPLACE VIEW vw_autores_estadisticas AS
SELECT a.id_autor,
       a.nombre,
       a.apellido,
       COUNT(DISTINCT p.id_publicacion) AS total_publicaciones,
       COUNT(cm.id_comentario) AS total_comentarios,
       MAX(p.fecha_publicacion) AS ultima_publicacion
FROM autores a
LEFT JOIN publicaciones p ON a.id_autor = p.id_autor
LEFT JOIN comentarios cm ON p.id_publicacion = cm.id_publicacion
GROUP BY a.id_autor;

-- Publicaciones con comentarios recientes (ultimos 30 dias) y cantidad
CREATE OR REPLACE VIEW vw_publicaciones_comentarios_recientes AS
SELECT p.id_publicacion,
       p.titulo,
       COUNT(cm.id_comentario) AS comentarios_ult_30dias
FROM publicaciones p
LEFT JOIN comentarios cm ON p.id_publicacion = cm.id_publicacion
  AND cm.fecha_creacion >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY p.id_publicacion
HAVING comentarios_ult_30dias > 0;

